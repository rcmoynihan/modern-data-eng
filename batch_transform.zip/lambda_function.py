import json
import os
import boto3
import logging
from datetime import datetime
from typing import Dict
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    try:
        # Find the latest partition
        latest_partition_key = find_latest_partition('raw')
        if not latest_partition_key:
            logger.warning("No partitions found in the bucket.")
            return {'status': 'No data'}

        # Extract base path for the latest partition
        base_path = '/'.join(latest_partition_key.split('/')[:-1])

        # Process the latest partition
        aggregated_data = process_partition('raw', base_path)

        # Write the output file to the staging bucket
        write_to_s3(aggregated_data, base_path)

        return {'status': 'Success'}

    except Exception as e:
        logger.error(f"Error in processing: {e}")
        return {'status': 'Error', 'message': str(e)}

def find_latest_partition(bucket_name: str) -> str:
    """
    Find the latest partition in the S3 bucket.

    :param bucket_name: The name of the S3 bucket.
    :return: The key of the latest partition.
    """
    try:
        paginator = s3_client.get_paginator('list_objects_v2')
        result = paginator.paginate(Bucket=bucket_name, Prefix='year=')
        
        latest_date = None
        latest_partition = None

        for page in result:
            if "Contents" in page:
                for obj in page['Contents']:
                    key = obj['Key']
                    date_str = key.split('/')[1]  # Assuming the format 'year=YYYY/month=MM/day=DD/...'
                    current_date = datetime.strptime(date_str, 'month=%m/day=%d')
                    if not latest_date or current_date > latest_date:
                        latest_date = current_date
                        latest_partition = key

        return latest_partition

    except Exception as e:
        logger.error(f"Error finding latest partition in {bucket_name}: {e}")
        return None

def process_partition(bucket_name: str, partition_path: str) -> Dict:
    """
    Process all files within a partition and aggregate session lengths.

    :param bucket_name: The name of the S3 bucket.
    :param partition_path: The base path for the partition.
    :return: A dict containing the aggregated session lengths.
    """
    aggregated_data = defaultdict(int)

    # Listing all files in the partition
    paginator = s3_client.get_paginator('list_objects_v2')
    result = paginator.paginate(Bucket=bucket_name, Prefix=partition_path)

    for page in result:
        if "Contents" in page:
            for obj in page['Contents']:
                key = obj['Key']
                # Read and process each file
                response = s3_client.get_object(Bucket=bucket_name, Key=key)
                file_content = response['Body'].read().decode('utf-8')
                data = json.loads(file_content)

                # Aggregate data
                product_name = data['product_name']
                session_length = data['session_length_ms']
                aggregated_data[product_name] += session_length

    return aggregated_data

def write_to_s3(data: Dict, original_key: str):
    """
    Write the aggregated data to the staging S3 bucket.

    :param data: The aggregated data dict.
    :param original_key: The original S3 key of the input file.
    """
    try:
        staging_bucket = 'staging'
        # Extract the date from the original key and format it for the new key
        date = datetime.strptime(original_key.split('/')[2], 'day=%d').strftime('%Y-%m-%d')
        new_key = f'aggregated/{date}.json'

        # Convert data to JSON
        json_data = json.dumps(data)

        # Write to S3
        s3_client.put_object(Bucket=staging_bucket, Key=new_key, Body=json_data)
        logger.info(f"Successfully wrote aggregated data to {staging_bucket}/{new_key}")

    except Exception as e:
        logger.error(f"Error writing data to {staging_bucket}: {e}")
        raise



# This is for testing the lambda function locally.
if __name__ == "__main__":
    mock_event = {
        'Records': [{
            's3': {
                'bucket': {'name': 'raw'},
                'object': {'key': 'year=2024/month=01/day=01/pageview_565.json'}
            }
        }]
    }
    lambda_handler(mock_event, None)
